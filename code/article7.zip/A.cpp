#include<bits/stdc++.h>
using namespace std;

#define int long long
const int maxn=1e5;

int p;
int a[maxn+5];
int ans;

signed main()
{
	freopen("A.in","r",stdin);
	freopen("A.out","w",stdout);
	
	scanf("%lld",&p);
	
	memset(a,0x3f,sizeof(a));
	for(int i=0;i<1e2;i++)
	{
		for(int j=0;j<p;j++)
		{
			a[(i*i+j*j)%p]=min(a[(i*i+j*j)%p],i);
		}
	}
	for(int i=0;i<p;i++) ans=max(ans,a[i]);
	
	printf("%lld",ans);
	
	return 0;
}
