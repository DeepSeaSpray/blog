#include<bits/stdc++.h>
using namespace std;

#define int long long
const int maxn=1e5;

struct Sct
{
	int v,p,q,l1,r1,l2,r2;
	Sct(int iv=0,int ip=0,int iq=0,int il1=0,int ir1=0,int il2=0,int ir2=0)
	{v=iv,p=ip,q=iq,l1=il1,r1=ir1,l2=il2,r2=ir2;}
};
bool operator <(const Sct &x,const Sct &y){return x.v<y.v;}

struct Node{int l,r,z,x,a,y,b,v,p,q;};
Node operator +(const Node x,const Node y)
{
	Node z;
	z.l=x.l;
	z.r=y.r;
	z.z=0;
	if(x.x>y.x) z.x=x.x,z.a=x.a;
	else z.x=y.x,z.a=y.a;
	if(x.y<y.y) z.y=x.y,z.b=x.b;
	else z.y=y.y,z.b=y.b;
	z.v=x.x-y.y;
	z.p=x.a;
	z.q=y.b;
	if(x.v>z.v) z.v=x.v,z.p=x.p,z.q=x.q;
	if(y.v>z.v) z.v=y.v,z.p=y.p,z.q=y.q;
	return z;
}

struct Sgt
{
	Node a[maxn<<2];
	
	inline void Update(int x,int k){a[x].x+=k,a[x].y+=k,a[x].z+=k;}
	inline void Pushup(int x){a[x]=a[x<<1]+a[x<<1|1];}
	inline void Pushdown(int x)
	{if(a[x].z) Update(x<<1,a[x].z),Update(x<<1|1,a[x].z),a[x].z=0;}
		
	void Build(int x,int l,int r)
	{
		a[x].l=l,a[x].r=r;
		if(l==r)
		{
			int ix;
			scanf("%lld",&ix);
			a[x].x=a[x].y=ix;
			a[x].a=a[x].b=a[x].p=a[x].q=l;
			a[x].v=0;
		}
		else
		{
			int mid=(r-l)/2+l;
			Build(x<<1,l,mid);
			Build(x<<1|1,mid+1,r);
			Pushup(x);
		}
	}
	void Modify(int x,int l,int r,int k)
	{
		if(l<=a[x].l&&a[x].r<=r) Update(x,k);
		else
		{
			Pushdown(x);
			int mid=(a[x].r-a[x].l)/2+a[x].l;
			if(l<=mid) Modify(x<<1,l,r,k);
			if(mid<r) Modify(x<<1|1,l,r,k);
			Pushup(x);
		}
	}
	Node Query(int x,int l,int r)
	{
		if(l<=a[x].l&&a[x].r<=r) return a[x];
		Pushdown(x);
		int mid=(a[x].r-a[x].l)/2+a[x].l;
		if(l<=mid&&mid<r) return Query(x<<1,l,r)+Query(x<<1|1,l,r);
		else if(l<=mid) return Query(x<<1,l,r);
		else return Query(x<<1|1,l,r);
	}
};
Sgt t;

priority_queue<Sct> qu;

inline void Add(int l1,int r1,int l2,int r2)
{
	if(l1==l2&&r1==r2)
	{
		Node tmp=t.Query(1,l1,r1);
		qu.push(Sct(tmp.v,tmp.p,tmp.q,l1,r1,l2,r2));
	}
	else
	{
		Node t1=t.Query(1,l1,r1),t2=t.Query(1,l2,r2);
		qu.push(Sct(t1.x-t2.y,t1.a,t2.b,l1,r1,l2,r2));
	}
}

int n,m;

signed main()
{
	freopen("D.in","r",stdin);
	freopen("D.out","w",stdout);
	
//	freopen("sample1.in","r",stdin);
//	freopen("sample1.out","w",stdout);
	
	int op,l,r,k;
	int ans;
	scanf("%lld%lld",&n,&m);
	t.Build(1,1,n);
	while(m--)
	{
		scanf("%lld%lld%lld%lld",&op,&l,&r,&k);
		if(op==1) t.Modify(1,l,r,k);
		else
		{
			while(!qu.empty()) qu.pop();
			Add(l,r,l,r);
			ans=0;
			while(k--)
			{
				Sct x=qu.top();
				qu.pop();
				ans+=x.v;
				if(x.l1==x.l2&&x.r1==x.r2)
				{
					if(x.p>x.l1)
						Add(x.l1,x.p-1,x.l1,x.p-1),Add(x.l1,x.p-1,x.p,x.r1);
					if(x.p!=x.q)
						Add(x.p,x.p,x.p,x.p);
					if(x.p<x.q-1)
						Add(x.p,x.p,x.p+1,x.q-1);
					if(x.q<x.r1)
						Add(x.p,x.p,x.q+1,x.r1);
					if(x.p<x.r1)
						Add(x.p+1,x.r1,x.p+1,x.r1);
				}
				else
				{
					if(x.p>x.l1)
						Add(x.l1,x.p-1,x.l2,x.r2);
					if(x.q>x.l2)
						Add(x.p,x.p,x.l2,x.q-1);
					if(x.q<x.r2)
						Add(x.p,x.p,x.q+1,x.r2);
					if(x.p<x.r1)
						Add(x.p+1,x.r1,x.l2,x.r2);
				}
			}
			printf("%lld\n",ans);
		}
	}
	
	return 0;
}

