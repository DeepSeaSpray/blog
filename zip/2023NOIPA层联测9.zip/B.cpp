#include<bits/stdc++.h>
using namespace std;

#define int long long 
const int maxn=3*1e3;
const int maxm=6*1e3;

int n,m;
struct edge{int u,v,nxt;};
edge e[maxm*2+5];
int hd[maxn+5],et;

int dis[maxn+5];
int cnt[maxn+5];
queue<int> qu;
int mn=LONG_LONG_MAX,ans;

inline void adde(int u,int v)
{
	e[et].u=u,e[et].v=v;
	e[et].nxt=hd[u],hd[u]=et++;
}

inline void solve(int x)
{
	int u,v;
	memset(dis,0x3f,sizeof(dis));
	memset(cnt,0,sizeof(cnt));
	dis[x]=cnt[x]=1;
	qu.push(x);
	while(!qu.empty())
	{
		u=qu.front();
		qu.pop();
		for(int i=hd[u];~i;i=e[i].nxt)
		{
			v=e[i].v;
			if(dis[v]>dis[u]+1) dis[v]=dis[u]+1,qu.push(v);
			if(dis[v]==dis[u]+1) cnt[v]+=cnt[u];
		}
	}
}

signed main()
{
	freopen("B.in","r",stdin);
	freopen("B.out","w",stdout);
	
	int u,v;
	memset(e,-1,sizeof(e));
	memset(hd,-1,sizeof(hd));
	scanf("%lld%lld",&n,&m);
	while(m--)
	{
		scanf("%lld%lld",&u,&v);
		solve(u);
		if(dis[v]<mn) mn=dis[v],ans=0;
		if(dis[v]==mn) ans+=cnt[v];
		adde(u,v);adde(v,u);
	}
	
	printf("%lld",ans);
	
	return 0;
}
