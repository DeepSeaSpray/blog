#include<bits/stdc++.h>
using namespace std;

#define int long long
const int maxn=1e6;
const int inf=0x3f3f3f3f3f3f3f3f;

int n;
int a[maxn+5];
int b[maxn+5];
int f[maxn+5];

signed main()
{
	freopen("C.in","r",stdin);
	freopen("C.out","w",stdout);
	
	scanf("%lld",&n);
	for(int i=1;i<=n;i++) scanf("%lld",&a[i]);
	for(int i=1;i<=n;i++) scanf("%lld",&b[i]);
	
	memset(f,0x3f,sizeof(f));
	f[0]=0;
	int k;
	for(int i=1;i<=n;i++)
	{
		k=lower_bound(f,f+n+1,a[i])-f-1;
		if(f[k]*b[k]<a[i]) f[k+1]=min(f[k+1],a[i]);
	}
	for(int i=1;i<=n;i++)
	{
		if(f[i]==inf)
		{
			printf("%lld",i-1);
			break;
		}
	}
	
	return 0;
}
