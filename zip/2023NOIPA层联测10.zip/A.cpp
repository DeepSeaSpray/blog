#include<bits/stdc++.h>
using namespace std;

#define int long long 
const int maxn=2*1e5;

int n,m;
int a[maxn+5];

int tmp,cnt=1;
int ans[maxn+5];

signed main()
{
	freopen("pack.in","r",stdin);
	freopen("pack.out","w",stdout);
	
	scanf("%lld%lld",&n,&m);
	for(int i=n;i>=1;i--) scanf("%lld",&a[i]);
	
	for(int i=1;i<=n;i++)
	{
		if(tmp+a[i]>m) cnt++,tmp=0;
		if(tmp+a[i]<=m) tmp+=a[i];
		ans[i]=cnt;
	}
	
	for(int i=n;i>=1;i--) printf("%lld ",ans[i]);
	
	return 0;
}
