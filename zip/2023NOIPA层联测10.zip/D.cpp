#include<bits/stdc++.h>
using namespace std;

const int maxn=15*1e5;
const int maxm=26;

int n,m;
char s[maxn+5];
int pre[maxn+5][maxm],nxt[maxn+5][maxm];
int f[maxn+5][maxm];
int lst[maxm];

signed main()
{
	freopen("seq.in","r",stdin);
	freopen("seq.out","w",stdout);
	
	scanf("%s",s+1);
	
	int i,j;
	n=strlen(s+1);
	for(i=1;i<=n;i++)
	{
		s[i]-='a';
		lst[(int)s[i]]=i;
		for(j=0;j<maxm;j++) pre[i][j]=lst[j];
	}
	memset(lst,0,sizeof(lst));
	for(i=n;i>=1;i--)
	{
		lst[(int)s[i]]=i;
		for(j=0;j<maxm;j++) nxt[i][j]=lst[j]; 
	}
	int t1,t2,t3,t4,tmp;
	for(i=n;i>=1;i--)
	{
		for(j=0;j<maxm;j++)
		{
			if(s[i]!=j)
			{
				tmp=nxt[i][j];
				if(tmp) f[i][j]=2+f[nxt[tmp][(int)s[i]]][j];
				else f[i][j]=1;
			}
		}
	}
	
	int l,r;
	int ans,ansa,ansb;
	scanf("%d",&m);
	while(m--)
	{
		ans=0;
		scanf("%d%d",&l,&r);
		for(i=0;i<26;i++)
		{
			for(j=0;j<26;j++)
			{
				if(i!=j)
				{
					t1=nxt[l][i],t2=nxt[r][i];
					t3=pre[r][i],t4=pre[r][j];
					if(t1>r) continue;
					if(t3>t4) tmp=f[t1][j]-f[t3][j]+1;
					else tmp=f[t1][j]-f[t2][j];
					if(tmp>ans) ans=tmp,ansa=i,ansb=j;
				}
			}
		}
		printf("%d %c%c\n",ans,ansa+'a',ansb+'a');
	}
	
	return 0;
}
