#include<bits/stdc++.h>
using namespace std;

#define ll long long
#define pii pair<int,int>
#define fi first
#define se second
const int maxn=3*1e5;
const int inf=1e6;

int n;
int c[maxn+5];
ll ans;

struct Sgt
{
	struct Node{int b,lzb,l,r;pii a,mn;};
	Node T[maxn<<2];
	
	inline void Update(int x,int lzb)
	{
		T[x].b=min(T[x].b,lzb);
		T[x].lzb=min(T[x].lzb,lzb);
		T[x].mn=min(T[x].mn,pii(T[x].a.fi+T[x].b,T[x].a.se));
	}
	inline void Pushup(int x)
	{
		T[x].a=min(T[x<<1].a,T[x<<1|1].a);
		T[x].mn=min(T[x<<1].mn,T[x<<1|1].mn);
	}
	inline void Pushdown(int x)
	{
		if(T[x].lzb!=inf)
		{
			Update(x<<1,T[x].lzb);
			Update(x<<1|1,T[x].lzb);
			T[x].lzb=inf;
		}
	}
	
	void Build(int x,int l,int r,int ng)
	{
		T[x].l=l,T[x].r=r;
		T[x].b=T[x].lzb=inf;
		T[x].mn=pii(inf,inf);
		T[x].a=pii(inf,inf);
		if(l==r) T[x].a=pii(c[l]*ng,l);
		else
		{
			int mid=(r-l)/2+l;
			Build(x<<1,l,mid,ng);
			Build(x<<1|1,mid+1,r,ng);
			Pushup(x);
		}
	}
	void ModifyA(int x,int p)
	{
		if(T[x].l==T[x].r)
		{
			T[x].b=T[x].lzb=inf;
			T[x].mn=pii(inf,inf);
			T[x].a=pii(inf,inf);
		}
		else
		{
			Pushdown(x);
			int mid=(T[x].r-T[x].l)/2+T[x].l;
			if(p<=mid) ModifyA(x<<1,p);
			else ModifyA(x<<1|1,p);
			Pushup(x);
		}
	}
	void ModifyB(int x,int l,int r,int lzb)
	{
		if(l<=T[x].l&&T[x].r<=r) Update(x,lzb);
		else
		{
//			Pushdown(x);
			int mid=(T[x].r-T[x].l)/2+T[x].l;
			if(l<=mid) ModifyB(x<<1,l,r,lzb);
			if(mid<r) ModifyB(x<<1|1,l,r,lzb);
			Pushup(x);
		}
	}
//	pii Query(int x,int l,int r)
//	{
//		if(l<=T[x].l&&T[x].r<=r) return T[x].mn;
//		else
//		{
//			Pushdown(x);
//			int mid=(T[x].r-T[x].l)/2+T[x].l;
//			pii tmp=pii(inf,inf);
//			if(l<=mid) tmp=min(tmp,Query(x<<1,l,r));
//			if(mid<r) tmp=min(tmp,Query(x<<1|1,l,r));
//			Pushup(x);
//			return tmp;
//		}
//	}
};
Sgt T1,T2;

inline int read()
{
	char ch=getchar();
	int res=0,ng=1;
	while(ch<'0'||ch>'9')
	{
		if(ch=='-') ng=-1;
		ch=getchar();
	}
	while('0'<=ch&&ch<='9')
	{
		res=res*10+ch-'0';
		ch=getchar();
	}
	return res*ng;
}

signed main()
{
	freopen("mst.in","r",stdin);
	freopen("mst.out","w",stdout);
	
	n=read();
	for(register int i=1;i<=n;i++) c[i]=read();
//	for(int i=1;i<=n;i++) c[i]=read();
	
	T1.Build(1,1,n,-1);
	T2.Build(1,1,n,+1);
	
	int u=1;
	pii tmp;
	T1.ModifyA(1,u);
	T2.ModifyA(1,u);
	
//	for(int i=1;i<n;i++)
	for(register int i=1;i<n;i++)
	{
		if(1<u) T1.ModifyB(1,1,u-1,+c[u]);
		if(u<n) T2.ModifyB(1,u+1,n,-c[u]);
		
//		tmp=min(T1.Query(1,1,n),T2.Query(1,1,n));
		tmp=min(T1.T[1].mn,T2.T[1].mn);
		ans+=tmp.fi;
		u=tmp.se;
		
		T1.ModifyA(1,u);
		T2.ModifyA(1,u);
		
//		printf("%lld %lld\n",u,ans);
	}
	
	printf("%lld",ans);
	
	return 0;
}

