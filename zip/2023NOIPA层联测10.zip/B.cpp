#include<bits/stdc++.h>
using namespace std;

#define int long long
const int maxn=10;

int n,m;
int a[maxn+5];

unordered_map<int,bool> mp;
int cnt;

void Dfs(int x)
{
	if(mp[x]) return;
	mp[x]=1;
	cnt++;
	if(x==0) return;
	for(int i=1;i<=m;i++) Dfs(x/a[i]);
}

signed main()
{
	freopen("set.in","r",stdin);
	freopen("set.out","w",stdout);
	
	scanf("%lld%lld",&n,&m);
	for(int i=1;i<=m;i++) scanf("%lld",&a[i]);
	
	sort(a+1,a+m+1);
	Dfs(n);
	
	printf("%lld",cnt);
	
	return 0;
}
